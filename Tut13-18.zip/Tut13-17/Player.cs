﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Youtube_Tutorials
{
    public class Player
    {
        Texture2D playerImage;
        Vector2 playerPosition, tempCurrentFrame;

        KeyboardState keyState;
        float moveSpeed;
        float speed = 200;

        Animation playerAnimation = new Animation();

        public void Initialize()
        {
            playerPosition = new Vector2(10, 10);
            playerAnimation.Initialize(playerPosition, new Vector2(4, 4));
            tempCurrentFrame = Vector2.Zero;
        }

        public void LoadContent(ContentManager Content)
        {
            playerImage = Content.Load<Texture2D>("Sprites/blackMale");
            playerAnimation.AnimationImage = playerImage;
        }

        public void Update(GameTime gameTime)
        {
            keyState = Keyboard.GetState();
            playerAnimation.Active = true;

            //moveSpeed *= (float)gameTime.ElapsedGameTime.TotalSeconds; //WON'T WORK
            moveSpeed = speed * (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (keyState.IsKeyDown(Keys.Down))
            {
                playerPosition.Y += moveSpeed;
                tempCurrentFrame.Y = 0;
            }
            else if (keyState.IsKeyDown(Keys.Up))
            {
                playerPosition.Y -= moveSpeed;
                tempCurrentFrame.Y = 3;
            }
            else if (keyState.IsKeyDown(Keys.Right))
            {
                playerPosition.X += moveSpeed;
                tempCurrentFrame.Y = 2;
            }
            else if (keyState.IsKeyDown(Keys.Left))
            {
                playerPosition.X -= moveSpeed;
                tempCurrentFrame.Y = 1;
            }
            else
                playerAnimation.Active = false;

            tempCurrentFrame.X = playerAnimation.CurrentFrame.X;

            playerAnimation.Position = playerPosition;
            playerAnimation.CurrentFrame = tempCurrentFrame;

            playerAnimation.Update(gameTime);
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            playerAnimation.Draw(spriteBatch);
            spriteBatch.DrawString(Game1.mainFont, gameTime.ElapsedGameTime.TotalSeconds.ToString(), new Vector2(10, 50), Color.Black);
        }
    }
}
