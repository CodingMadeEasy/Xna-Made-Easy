﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Youtube_Tutorials
{
    public class Camera
    {
        Vector2 position;
        Matrix viewMatrix;
        float scale = 1.0f;
        float rotation = 0.0f;

        public Matrix ViewMatrix
        {
            get { return viewMatrix; }
        }

        public void Update(Vector2 playerPosition, Viewport view)
        {
            position.X = ((playerPosition.X + 16) - (view.Width / 2) / scale);
            position.Y = ((playerPosition.Y + 24) - (view.Height / 2) / scale);

            if (position.X < 0)
                position.X = 0;
            if (position.Y < 0)
                position.Y = 0;

            if (Keyboard.GetState().IsKeyDown(Keys.Z))
                scale += 0.01f;
            else if (Keyboard.GetState().IsKeyDown(Keys.X))
                scale -= 0.01f;

            if (Keyboard.GetState().IsKeyDown(Keys.C))
                rotation++; 
            else if (Keyboard.GetState().IsKeyDown(Keys.V))
                rotation--;

            if (Math.Abs(rotation) >= 360)
                rotation = 0; 

            viewMatrix = Matrix.CreateTranslation(new Vector3(-position, 0)) *
                Matrix.CreateScale(scale) *
                Matrix.CreateRotationZ(MathHelper.ToRadians(-rotation));
        }
    }
}
